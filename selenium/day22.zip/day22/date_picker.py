import datetime
# t1 = datetime.datetime.now()
t1 = datetime.datetime(2023, 12,2,6,2,40)
##year month date time min sec millisec
print(t1.strftime("%m/%d/%Y"))