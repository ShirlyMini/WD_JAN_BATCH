class Test_Suite1:
    def test_TC1(self):
        print("this is test case 1")

    def test_TC2(self):
        print("this is test case 2")