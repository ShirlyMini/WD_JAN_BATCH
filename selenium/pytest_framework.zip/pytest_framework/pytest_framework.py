# rule
#Test suite (class/Module)- collection of test case(method)
# file name-Test_*/Test*/test_*/test*,
# **classname-Test_*/Test*,
# **method-test_*/test*

import pytest
